# Moved

Please see here: https://github.com/appacademy/prep-work/blob/master/pre-course/homework.md.
