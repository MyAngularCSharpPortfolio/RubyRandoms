def ctof(num)
((num*(9.0/5.0)) + 32)
end

def ftoc(num)
((num*1.0-32)*(5.0/9.0))
end
