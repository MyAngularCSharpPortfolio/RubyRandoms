# Mailing List Signup

Once you've been formally sent an offer of acceptance, please sign up
for your cycle's mailing list. **Please don't sign up before you've
been sent an acceptance letter**.

* [2013-01-07 (SF)][2013-01-07-sf]
* [2013-03-11 (SF)][2013-03-11-sf]
* [2013-04-15 (NY)][2013-04-15-ny]
* [2013-05-13 (SF)][2013-05-13-sf]
* [2013-06-17 (NY)][2013-06-17-ny]
* [2013-07-15 (SF)][2013-07-15-sf]
* [2013-08-19 (NY)][2013-08-19-ny]
* [2013-09-16 (SF)][2013-09-16-sf]
* [2013-10-21 (NY)][2013-10-21-ny]
* [2013-11-18 (SF)][2013-11-18-sf]
* [2013-12-30 (NY)][2013-12-30-ny]
* [2014-01-27 (SF)][2014-01-27-sf]

Please also **send your github username to admin@appacademy.io** so that
we can add you to the curriculum repos.

[2013-01-07-sf]: https://groups.google.com/forum/?fromgroups&hl=en#!forum/appacademy-january-2013
[2013-03-11-sf]: https://groups.google.com/forum/?fromgroups&hl=en#!forum/app-academy-sf-march
[2013-04-15-ny]: https://groups.google.com/forum/?fromgroups&hl=en#!forum/app-academy-ny-april-2013
[2013-05-13-sf]: https://groups.google.com/forum/?fromgroups&hl=en#!forum/app-academy-sf-may-2013
[2013-06-17-ny]: https://groups.google.com/forum/?fromgroups&hl=en#!forum/app-academy-ny-june-2013
[2013-07-15-sf]: https://groups.google.com/forum/?fromgroups&hl=en#!forum/app-academy-sf-july-2013
[2013-08-19-ny]: https://groups.google.com/forum/?hl=en&fromgroups#!forum/app-academy-ny-aug-2013
[2013-09-16-sf]: https://groups.google.com/forum/?hl=en&fromgroups#!forum/app-academy-sf-sep-2013
[2013-10-21-ny]: https://groups.google.com/forum/?hl=en&fromgroups#!forum/app-academy-ny-october
[2013-11-18-sf]: https://groups.google.com/forum/?hl=en#!forum/app-academy-sf-nov-2013-cohort
[2013-12-30-ny]: https://groups.google.com/forum/?hl=en#!forum/app-academy-ny-dec-2013-cohort
[2014-01-27-sf]: https://groups.google.com/forum/?hl=en#!forum/app-academy-sf-jan-2014-cohort
