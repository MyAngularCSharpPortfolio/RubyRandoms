def wonky_coins(n)
end
