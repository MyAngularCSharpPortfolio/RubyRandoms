def word_unscrambler(str, words)
end
