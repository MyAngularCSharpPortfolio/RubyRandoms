

class Friend


def greeting(who = nil)

return "Hello, #{who}!" if who.nil? == false


"Hello!"


end
end
